# Original OBJ companion-file control

CC0-1.0, InspectMesh, 27 October 2026. Reproduce with
`python3 scripts/generate-handoff-assets.py` from the frontend repository.

Inventory: sample.obj, sample.mtl, textures/checker.png, README.md.
The closed block has eight coordinate vertices, six outward-wound quad faces,
and spans X=0..20, Y=0..10, Z=0..5. Coordinates are intended as millimetres;
OBJ has no authoritative unit declaration. Analytical volume is 1,000 mm3.
Each face maps the original blue/yellow 16 x 16 checker texture through four UVs.
The OBJ references sample.mtl, whose checker material references textures/checker.png.

Extract the entire ZIP into a fresh directory. Open sample.obj in an application
that supports OBJ/MTL/image textures; record its version, import options, bounds,
and actual appearance. On a working copy remove the texture, then the MTL, to
observe the different missing-reference stages. Preserve the complete original.
Geometry may still open when appearance is missing. No receiving-application
appearance or printed-colour observation has been made for this control.
InspectMesh does not accept OBJ, MTL or ZIP uploads in its STL/3MF tools.
